import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/Layout";
import Dashboard from "@/pages/dashboard";
import InvoiceList from "@/pages/invoices/index";
import InvoiceEditor from "@/pages/invoices/editor";
import CustomerList from "@/pages/customers/index";
import CustomerForm from "@/pages/customers/form";
import CustomerDetail from "@/pages/customers/detail";
import VehicleList from "@/pages/vehicles/index";
import VehicleForm from "@/pages/vehicles/form";
import VehicleDetail from "@/pages/vehicles/detail";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: 1,
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />

        {/* Invoices */}
        <Route path="/invoices" component={InvoiceList} />
        <Route path="/invoices/new" component={() => <InvoiceEditor />} />
        <Route path="/invoices/:id/edit" component={({ params }) => <InvoiceEditor id={parseInt(params.id)} />} />
        <Route path="/invoices/:id" component={({ params }) => <InvoiceEditor id={parseInt(params.id)} />} />

        {/* Customers */}
        <Route path="/customers" component={CustomerList} />
        <Route path="/customers/new" component={() => <CustomerForm />} />
        <Route path="/customers/:id/edit" component={({ params }) => <CustomerForm id={parseInt(params.id)} />} />
        <Route path="/customers/:id" component={({ params }) => <CustomerDetail id={parseInt(params.id)} />} />

        {/* Vehicles */}
        <Route path="/vehicles" component={VehicleList} />
        <Route path="/vehicles/new" component={() => <VehicleForm />} />
        <Route path="/vehicles/:id/edit" component={({ params }) => <VehicleForm id={parseInt(params.id)} />} />
        <Route path="/vehicles/:id" component={({ params }) => <VehicleDetail id={parseInt(params.id)} />} />

        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
