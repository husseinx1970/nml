import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";
import { formatDate } from "@/lib/utils";

// ─── Företagsuppgifter ─────────────────────────────────────────────────────────
const CO = {
  name:     "Utby Snabb Bilservice AB",
  addr1:    "Vagnmakaregatan 2",
  addr2:    "415 07 Göteborg",
  tel:      "076-422 10 51",
  mobil:    "072-004 09 36",
  email:    "info@utbysnabbbilservice.se",
  web:      "www.utbysnabbbilservice.se",
  bankgiro: "5930-0897",
  plusgiro: "",
  momsreg:  "SE000520655201",
  orgNr:    "000520-6552",
};

const BLK = "#000000";
const DGREY = "#444444";
const GREY = "#777777";
const LGREY = "#aaaaaa";
const BORDER = "#bbbbbb";
const ROW_ALT = "#f5f5f5";
const LINE = "#999999";

const S = StyleSheet.create({
  page: {
    fontFamily:        "Helvetica",
    fontSize:          8.5,
    color:             BLK,
    backgroundColor:   "#ffffff",
    paddingTop:        28,
    paddingBottom:     55,
    paddingHorizontal: 34,
  },

  // ── TOPRAD ─────────────────────────────────────────────────────────────────
  topRow: {
    flexDirection:  "row",
    justifyContent: "space-between",
    alignItems:     "flex-start",
    marginBottom:   8,
  },
  coName: {
    fontSize:   17,
    fontFamily: "Helvetica-Bold",
    color:      BLK,
  },
  coSub: {
    fontSize:  8,
    color:     GREY,
    marginTop: 2,
  },
  docTitle: {
    fontSize:   24,
    fontFamily: "Helvetica-Bold",
    color:      BLK,
    textAlign:  "right",
  },

  // ── METARAD ─────────────────────────────────────────────────────────────────
  metaStrip: {
    flexDirection:     "row",
    borderTopWidth:    1.5,
    borderTopColor:    BLK,
    borderBottomWidth: 0.5,
    borderBottomColor: BORDER,
    paddingTop:        4,
    paddingBottom:     4,
    marginBottom:      8,
  },
  metaCell: {
    flex:        1,
    paddingRight: 6,
  },
  metaLabel: {
    fontSize:     7,
    color:        LGREY,
    marginBottom: 1,
  },
  metaVal: {
    fontSize:   9,
    fontFamily: "Helvetica-Bold",
    color:      BLK,
  },

  // ── ADRESSBLOCK ─────────────────────────────────────────────────────────────
  addrRow: {
    flexDirection: "row",
    marginBottom:  6,
  },
  addrCol: {
    flex:       1,
    paddingRight: 16,
  },
  addrTag: {
    fontSize:     7,
    color:        LGREY,
    marginBottom: 3,
  },
  addrBold: {
    fontSize:   9,
    fontFamily: "Helvetica-Bold",
    color:      BLK,
    marginBottom: 1,
  },
  addrLine: {
    fontSize:   8,
    color:      DGREY,
    lineHeight: 1.45,
  },

  // ── SEPARATOR ──────────────────────────────────────────────────────────────
  sep: {
    borderBottomWidth: 0.5,
    borderBottomColor: BORDER,
    marginVertical:    5,
  },
  sepBold: {
    borderBottomWidth: 1,
    borderBottomColor: BLK,
    marginBottom:      5,
    marginTop:         0,
  },

  // ── INFORADER (label  value  |  label  value) ─────────────────────────────
  infoSection: {
    marginBottom: 2,
  },
  infoRowLine: {
    flexDirection:     "row",
    paddingVertical:   2.5,
    borderBottomWidth: 0.3,
    borderBottomColor: BORDER,
  },
  infoHalf: {
    flex:       1,
    flexDirection: "row",
    paddingRight: 10,
  },
  infoLbl: {
    fontSize: 7.5,
    color:    GREY,
    width:    "55%",
  },
  infoVal: {
    fontSize:   7.5,
    fontFamily: "Helvetica-Bold",
    color:      BLK,
    flex:       1,
  },

  // ── TABELL ──────────────────────────────────────────────────────────────────
  table: {
    borderTopWidth: 1,
    borderTopColor: BLK,
    marginTop:      8,
  },
  tHead: {
    flexDirection:     "row",
    backgroundColor:   "#ebebeb",
    borderBottomWidth: 0.8,
    borderBottomColor: BLK,
    paddingVertical:   3,
    paddingHorizontal: 3,
  },
  th: {
    fontSize:      7,
    fontFamily:    "Helvetica-Bold",
    color:         DGREY,
    textTransform: "uppercase",
  },
  tRow: {
    flexDirection:     "row",
    paddingVertical:   2.8,
    paddingHorizontal: 3,
    borderBottomWidth: 0.3,
    borderBottomColor: BORDER,
  },
  tRowAlt: {
    backgroundColor: ROW_ALT,
  },
  td: {
    fontSize: 8,
    color:    BLK,
  },
  tdGrey: {
    fontSize: 7.5,
    color:    GREY,
  },
  tdBold: {
    fontSize:   8,
    fontFamily: "Helvetica-Bold",
    color:      BLK,
  },

  // Kolumnbredder
  cNr:    { width: "5%"  },
  cDesc:  { flex:  1     },
  cArt:   { width: "11%" },
  cAntal: { width: "7%", textAlign: "right" as const },
  cEnh:   { width: "6%", textAlign: "center" as const },
  cPris:  { width: "10%", textAlign: "right" as const },
  cBel:   { width: "10%", textAlign: "right" as const },

  // ── SUMMOR ──────────────────────────────────────────────────────────────────
  sumSection: {
    borderTopWidth: 1,
    borderTopColor: BLK,
  },
  sumRow: {
    flexDirection:     "row",
    paddingVertical:   2.5,
    paddingHorizontal: 3,
    borderBottomWidth: 0.3,
    borderBottomColor: BORDER,
  },
  sumLbl: {
    flex:      1,
    textAlign: "right" as const,
    fontSize:  8,
    color:     GREY,
    paddingRight: 5,
  },
  sumVal: {
    width:    "10%",
    textAlign: "right" as const,
    fontSize: 8,
    color:    BLK,
  },
  sumGrandRow: {
    flexDirection:   "row",
    paddingVertical: 4,
    paddingHorizontal: 3,
    backgroundColor: "#e8e8e8",
  },
  sumGrandLbl: {
    flex:      1,
    textAlign: "right" as const,
    fontSize:  9,
    fontFamily: "Helvetica-Bold",
    color:     BLK,
    paddingRight: 5,
  },
  sumGrandVal: {
    width:    "10%",
    textAlign: "right" as const,
    fontSize: 9,
    fontFamily: "Helvetica-Bold",
    color:    BLK,
  },

  // ── SIDFOT ──────────────────────────────────────────────────────────────────
  footer: {
    position:   "absolute",
    bottom:     18,
    left:       34,
    right:      34,
    borderTopWidth: 0.7,
    borderTopColor: LINE,
    paddingTop: 5,
    flexDirection: "row",
  },
  footCol: {
    flex:       1,
    paddingRight: 10,
  },
  footBold: {
    fontSize:   7.5,
    fontFamily: "Helvetica-Bold",
    color:      BLK,
    marginBottom: 1,
  },
  footLbl: {
    fontSize:     6.5,
    color:        LGREY,
    marginTop:    2,
    marginBottom: 0.5,
  },
  footVal: {
    fontSize: 7.5,
    color:    DGREY,
  },
});

// ─── Hjälpfunktioner ──────────────────────────────────────────────────────────
function fmt(n: number): string {
  return n.toLocaleString("sv-SE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function InfoRow({ left, right }: {
  left: [string, string | undefined | null],
  right?: [string, string | undefined | null],
}) {
  return (
    <View style={S.infoRowLine}>
      <View style={S.infoHalf}>
        <Text style={S.infoLbl}>{left[0]}</Text>
        <Text style={S.infoVal}>{left[1] || "–"}</Text>
      </View>
      {right && (
        <View style={S.infoHalf}>
          <Text style={S.infoLbl}>{right[0]}</Text>
          <Text style={S.infoVal}>{right[1] || "–"}</Text>
        </View>
      )}
    </View>
  );
}

// ─── Typer ────────────────────────────────────────────────────────────────────
interface InvoiceItem {
  id: number;
  itemType: string;
  articleNumber?: string | null;
  description: string;
  quantity: number;
  unit?: string | null;
  unitPrice: number;
  discountPercent: number;
  vatRate: number;
  lineTotal: number;
}

interface Props {
  isDraft?: boolean;
  invoice: {
    invoiceNumber: string;
    orderNumber?: string | null;
    offerNumber?: string | null;
    invoiceDate: string;
    dueDate?: string | null;
    paymentTerms?: string | null;
    customerName?: string | null;
    customerOrgNumber?: string | null;
    customerEmail?: string | null;
    customerPhone?: string | null;
    customerAddress?: string | null;
    customerPostalCode?: string | null;
    customerCity?: string | null;
    registrationNumber?: string | null;
    vehicleMake?: string | null;
    vehicleModel?: string | null;
    vehicleYear?: number | null;
    vin?: string | null;
    mileage?: number | null;
    mechanic?: string | null;
    internalReference?: string | null;
    workshopNotes?: string | null;
    subtotal: number;
    vatAmount: number;
    total: number;
  };
  items: InvoiceItem[];
}

// ─── Komponent ────────────────────────────────────────────────────────────────
export function InvoicePdf({ invoice, items }: Props) {
  // Moms per skattesats
  const vatByRate: Record<number, number> = {};
  for (const it of items) {
    const net = Number(it.quantity) * Number(it.unitPrice) * (1 - Number(it.discountPercent) / 100);
    vatByRate[it.vatRate] = (vatByRate[it.vatRate] ?? 0) + net * (Number(it.vatRate) / 100);
  }

  const postalCity = [invoice.customerPostalCode, invoice.customerCity].filter(Boolean).join("  ");

  return (
    <Document title={`Faktura ${invoice.invoiceNumber}`} author={CO.name}>
      <Page size="A4" style={S.page}>

        {/* ── TOPRAD ─────────────────────────────────────────────────────── */}
        <View style={S.topRow}>
          <View>
            <Text style={S.coName}>{CO.name}</Text>
            <Text style={S.coSub}>{CO.addr1}  ·  {CO.addr2}</Text>
          </View>
          <Text style={S.docTitle}>Faktura</Text>
        </View>

        {/* ── METARAD ────────────────────────────────────────────────────── */}
        <View style={S.metaStrip}>
          <View style={S.metaCell}>
            <Text style={S.metaLabel}>Fakturanr.</Text>
            <Text style={S.metaVal}>{invoice.invoiceNumber}</Text>
          </View>
          <View style={S.metaCell}>
            <Text style={S.metaLabel}>Ordernr.</Text>
            <Text style={S.metaVal}>{invoice.orderNumber || "–"}</Text>
          </View>
          <View style={S.metaCell}>
            <Text style={S.metaLabel}>Offertnr.</Text>
            <Text style={S.metaVal}>{invoice.offerNumber || "–"}</Text>
          </View>
          <View style={S.metaCell}>
            <Text style={S.metaLabel}>Er referens</Text>
            <Text style={S.metaVal}>{invoice.internalReference || "–"}</Text>
          </View>
          <View style={{ width: 28 }}>
            <Text style={S.metaLabel}>Sida</Text>
            <Text style={S.metaVal}>1</Text>
          </View>
        </View>

        {/* ── ADRESSBLOCK ────────────────────────────────────────────────── */}
        <View style={S.addrRow}>
          <View style={S.addrCol}>
            <Text style={S.addrTag}>Från</Text>
            <Text style={S.addrBold}>{CO.name}</Text>
            <Text style={S.addrLine}>{CO.addr1}</Text>
            <Text style={S.addrLine}>{CO.addr2}</Text>
            <Text style={[S.addrLine, { marginTop: 3 }]}>Tel: {CO.tel}  ·  Mobil: {CO.mobil}</Text>
            <Text style={S.addrLine}>{CO.email}</Text>
          </View>
          <View style={S.addrCol}>
            <Text style={S.addrTag}>Faktura till</Text>
            {invoice.customerName
              ? <Text style={S.addrBold}>{invoice.customerName}</Text>
              : <Text style={S.addrBold}>–</Text>
            }
            {invoice.customerAddress
              ? <Text style={S.addrLine}>{invoice.customerAddress}</Text>
              : null
            }
            {postalCity
              ? <Text style={S.addrLine}>{postalCity}</Text>
              : null
            }
            {invoice.customerOrgNumber
              ? <Text style={[S.addrLine, { marginTop: 2 }]}>Org.nr: {invoice.customerOrgNumber}</Text>
              : null
            }
            {invoice.customerPhone
              ? <Text style={S.addrLine}>Tel: {invoice.customerPhone}</Text>
              : null
            }
          </View>
        </View>

        <View style={S.sepBold} />

        {/* ── INFORADER — datum & betalning ──────────────────────────────── */}
        <View style={S.infoSection}>
          <InfoRow
            left={["Fakturadatum", formatDate(invoice.invoiceDate)]}
            right={["Förfallodatum", formatDate(invoice.dueDate)]}
          />
          <InfoRow
            left={["Betalningsvillkor", invoice.paymentTerms || "30 dagar"]}
            right={["Bankgiro", CO.bankgiro]}
          />
          <InfoRow
            left={["Momsreg.nr", CO.momsreg]}
            right={invoice.mechanic ? ["Vår referens", invoice.mechanic] : undefined}
          />
        </View>

        {/* ── INFORADER — fordon (visas om reg.nr finns) ─────────────────── */}
        {(invoice.registrationNumber || invoice.vehicleMake) && (
          <View style={[S.infoSection, { marginTop: 3 }]}>
            <View style={S.sep} />
            {invoice.vehicleMake && (
              <InfoRow
                left={["Märkeskod", invoice.vehicleMake]}
                right={["Reg.nr", invoice.registrationNumber]}
              />
            )}
            {!invoice.vehicleMake && invoice.registrationNumber && (
              <InfoRow
                left={["Reg.nr", invoice.registrationNumber]}
              />
            )}
            {invoice.vehicleModel && (
              <InfoRow
                left={["Modell", invoice.vehicleModel]}
                right={invoice.vehicleYear ? ["Årsmodell", String(invoice.vehicleYear)] : undefined}
              />
            )}
            {(invoice.vin || invoice.mileage) && (
              <InfoRow
                left={["Chassinummer", invoice.vin]}
                right={invoice.mileage
                  ? ["Aktuell mätarställning (km)", Number(invoice.mileage).toLocaleString("sv-SE")]
                  : undefined
                }
              />
            )}
          </View>
        )}

        {/* ── ANTECKNINGAR ───────────────────────────────────────────────── */}
        {invoice.workshopNotes && (
          <View style={{ marginTop: 4 }}>
            <View style={S.sep} />
            <InfoRow left={["Verkstadsanteckningar", invoice.workshopNotes]} />
          </View>
        )}

        {/* ── ARTIKELTABELL ──────────────────────────────────────────────── */}
        <View style={S.table}>
          <View style={S.tHead}>
            <Text style={[S.th, S.cNr]}>Nr.</Text>
            <Text style={[S.th, S.cDesc]}>Beskrivning</Text>
            <Text style={[S.th, S.cArt]}>Art.nr</Text>
            <Text style={[S.th, S.cAntal]}>Antal</Text>
            <Text style={[S.th, S.cEnh]}>Enhet</Text>
            <Text style={[S.th, S.cPris]}>Pris</Text>
            <Text style={[S.th, S.cBel]}>Belopp</Text>
          </View>

          {items.map((item, idx) => {
            const net = Number(item.quantity) * Number(item.unitPrice) * (1 - Number(item.discountPercent) / 100);
            const inclVat = net + net * (Number(item.vatRate) / 100);
            const isLabor = item.itemType === "labor";
            return (
              <View key={item.id} style={[S.tRow, idx % 2 === 1 ? S.tRowAlt : {}]} wrap={false}>
                <Text style={[S.tdGrey, S.cNr]}>{idx + 1}</Text>
                <Text style={[S.td, S.cDesc, isLabor ? { fontFamily: "Helvetica-Oblique" } : {}]}>
                  {item.description}
                  {item.discountPercent > 0 ? `  (−${item.discountPercent}%)` : ""}
                </Text>
                <Text style={[S.tdGrey, S.cArt, { fontSize: 7 }]}>{item.articleNumber ?? ""}</Text>
                <Text style={[S.td, S.cAntal]}>
                  {Number(item.quantity).toLocaleString("sv-SE")}
                </Text>
                <Text style={[S.tdGrey, S.cEnh]}>{item.unit ?? (isLabor ? "tim" : "st")}</Text>
                <Text style={[S.td, S.cPris]}>{fmt(Number(item.unitPrice))}</Text>
                <Text style={[S.tdBold, S.cBel]}>{fmt(inclVat)}</Text>
              </View>
            );
          })}

          {/* ── Summeringsrader ── */}
          <View style={S.sumSection}>
            <View style={S.sumRow}>
              <Text style={S.sumLbl}>Delsumma, SEK</Text>
              <Text style={S.sumVal}>{fmt(invoice.subtotal)}</Text>
            </View>
            {Object.entries(vatByRate)
              .sort(([a], [b]) => Number(b) - Number(a))
              .map(([rate, vat]) => (
                <View key={rate} style={S.sumRow}>
                  <Text style={S.sumLbl}>Moms {rate}%, SEK</Text>
                  <Text style={S.sumVal}>{fmt(vat)}</Text>
                </View>
              ))}
            {Object.keys(vatByRate).length === 0 && (
              <View style={S.sumRow}>
                <Text style={S.sumLbl}>Moms 25%, SEK</Text>
                <Text style={S.sumVal}>{fmt(invoice.vatAmount)}</Text>
              </View>
            )}
            <View style={S.sumGrandRow}>
              <Text style={S.sumGrandLbl}>Att betala inkl. moms, SEK</Text>
              <Text style={S.sumGrandVal}>{fmt(invoice.total)}</Text>
            </View>
          </View>
        </View>

        {/* ── SIDFOT ─────────────────────────────────────────────────────── */}
        <View style={S.footer} fixed>
          <View style={S.footCol}>
            <Text style={S.footBold}>{CO.name}</Text>
            <Text style={S.footVal}>{CO.addr1}</Text>
            <Text style={S.footVal}>{CO.addr2}</Text>
          </View>
          <View style={S.footCol}>
            <Text style={S.footLbl}>Telefon</Text>
            <Text style={S.footVal}>{CO.tel}</Text>
            <Text style={S.footLbl}>E-post</Text>
            <Text style={S.footVal}>{CO.email}</Text>
            <Text style={S.footLbl}>Hemsida</Text>
            <Text style={S.footVal}>{CO.web}</Text>
          </View>
          <View style={S.footCol}>
            <Text style={S.footLbl}>Bankgiro</Text>
            <Text style={S.footVal}>{CO.bankgiro}</Text>
            <Text style={S.footLbl}>Moms reg. nr.</Text>
            <Text style={S.footVal}>{CO.momsreg}</Text>
          </View>
          <View style={{ paddingRight: 0 }}>
            <Text style={S.footLbl}>Org.nr</Text>
            <Text style={S.footVal}>{CO.orgNr}</Text>
            <Text style={[S.footBold, { marginTop: 6 }]}>Godkänd för F-skatt</Text>
          </View>
        </View>

      </Page>
    </Document>
  );
}
