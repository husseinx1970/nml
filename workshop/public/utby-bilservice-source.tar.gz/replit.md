# Utby Snabb Bilservice — Verkstadssystem

Swedish automotive workshop management system for Utby Snabb Bilservice, Göteborg. Full CRUD for invoices (with PDF generation), customers, and vehicles. Enterprise PBS Faktura style with Swedish VAT (moms 25%).

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS (artifacts/workshop, port 20070)
- API: Express 5 (artifacts/api-server, port 8080)
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- PDF: @react-pdf/renderer
- Charts: Recharts
- Forms: react-hook-form
- Routing: wouter

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI contract (source of truth for all routes)
- `lib/api-client-react/src/generated/api.ts` — generated React Query hooks
- `lib/api-zod/src/generated/` — generated Zod schemas
- `lib/db/src/schema/` — Drizzle ORM table definitions (customers, vehicles, invoices)
- `artifacts/api-server/src/routes/` — Express route handlers (customers, vehicles, invoices, dashboard)
- `artifacts/workshop/src/pages/` — React pages (dashboard, invoices, customers, vehicles)
- `artifacts/workshop/src/components/` — Layout, StatusBadge, InvoicePdf
- `artifacts/workshop/src/index.css` — CSS theme (steel-grey sidebar, amber primary)

## Architecture decisions

- Contract-first: OpenAPI spec drives all codegen; never write API clients by hand
- Invoice items are always fetched inline with the invoice (InvoiceDetail schema includes `items[]`)
- Swedish locale throughout: dates, currency (sv-SE Intl formatters), status labels
- PDF generated entirely client-side via @react-pdf/renderer — no server involvement
- Sidebar navigation with wouter for SPA routing under base path

## Product

- **Dashboard**: stats cards (customers, vehicles, invoices, revenue), status breakdown, monthly revenue bar chart, recent invoices
- **Fakturor**: list with search + status filter, inline status transitions (Utkast→Skickad→Betald), delete
- **Faktura editor**: full form with customer/vehicle selector dropdowns, line items table (type, art.nr, qty, price, discount, VAT), auto-calculated totals, PDF download
- **Kunder**: list with search, CRUD forms, customer detail with vehicle/invoice history
- **Fordon**: list with search, CRUD forms, vehicle detail with service history

## Company info

- Utby Snabservice (UTBY SNABSERVICE on PDF)
- VAGNMAKAREGATAN 2, 41507 GÖTEBORG
- Tel: 076-4221051
- Mobil: 0720040936
- info@utbysnabbbilservice.se
- Momsreg nr/VAT-nr: 000520-6552
- Bankgiro: 5930-0897
- Org.nr: 556XXX-XXXX (placeholder)

## User preferences

- All UI text in Swedish
- Status labels: Utkast / Skickad / Betald / Förfallen / Avbruten
- Item types: Reservdel / Arbete / Olja / Däckavgift / Miljöavgift / Diagnos / Fastpris / Rabatt / Övrigt
- VAT: 25% default (Swedish moms), also supports 12%, 6%, 0%
- Currency formatting: sv-SE locale (7 000,00 kr)

## Gotchas

- Run `pnpm --filter @workspace/api-spec run codegen` after any OpenAPI spec change
- Run `pnpm --filter @workspace/db run push` after any schema change (dev DB only)
- Zod generated schema names: body schemas use `CreateXBody`/`UpdateXBody` (NOT `XInput`)
- The `useListInvoices` filter param is `status` (singular), not `statuses`
- Never use `console.log` in server code — use `req.log` in route handlers

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
